package es.ucm.fdi.tp.project6;

public class Test1Server {
	public static void main(String [] args) {
		 String [] as = { "-am", "server", "-g", "ataxx", "-p","X,O" };
		 Main.main(as);
		 }
}
