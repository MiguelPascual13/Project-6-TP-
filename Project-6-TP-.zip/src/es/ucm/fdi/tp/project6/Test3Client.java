package es.ucm.fdi.tp.project6;

public class Test3Client {

	public static void main(String [] args) {
		 String [] as = { "-am", "client", "-aialg", "minmax", "-md","5"  };
		 Main.main(as);
	}

}
