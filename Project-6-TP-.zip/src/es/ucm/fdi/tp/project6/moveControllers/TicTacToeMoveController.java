package es.ucm.fdi.tp.project6.moveControllers;

@SuppressWarnings("serial")
public class TicTacToeMoveController extends ConnectNMoveController {
}
