package es.ucm.fdi.tp.project5.moveControllers;

@SuppressWarnings("serial")
public class TicTacToeMoveController extends ConnectNMoveController {
}
